package Project_2;

public class Main_File {

	public static void main(String[] args) {
	
		
		
		System.out.println();
		System.out.println("\t\t\t=====================================================================================");
		System.out.println("\t\t\t(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)");
		System.out.println("\t\t\t=====================================================================================");
		System.out.println("\t\t\t\t\t*************      CAKE-O-LICIOUS       *************");
		System.out.println("\t\t\t\t\t*************        ༼ つ ◕_◕ ༽つ         *************");
		System.out.println("\t\t\t\t\t*************     Home Sweet Bakery     *************");
		System.out.println("\t\t\t=====================================================================================");
		System.out.println("\t\t\t(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)(*_*)");
		System.out.println("\t\t\t=====================================================================================");
		System.out.println("          ");
		System.out.println("          ");
		System.out.println("          ");
		Register_class R1=new Register_class();
		R1.Registeration();
//		Product_class p1=new Product_class();
//		p1.product_list();
//		
//		Cart_Class c1=new Cart_Class();
//		c1.cart();
		//c1.bill();
	}
	

}
